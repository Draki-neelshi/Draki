import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

public class BICHOSCRUD extends JFrame {
    JButton agregar = new JButton("Agregar");
    JButton limpiar = new JButton("Limpiar");
    JButton borrar = new JButton("Borrar");
    JButton actualizar = new JButton("Actualizar"); // Nuevo botón de actualizar
    JButton salir = new JButton("Salir");
    JTextField ID_Usuario = new JTextField(10);
    JTextField Nombre = new JTextField(10);
    JComboBox<String> Sexo = new JComboBox<>();
    JTextField Correo = new JTextField(10);
    JTextField Pais = new JTextField(10);
    JTable tabla;
    JScrollPane spTexto;
    DefaultTableModel tm;
    int contador = 0;
    Connection conn;

    public static void main(String[] args) {
        new BICHOSCRUD();

    }

    public BICHOSCRUD() {
        setTitle("Datos de identificación");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        add(new FormPanel());
        pack();
        setResizable(false);
        setLocationRelativeTo(null);
        setVisible(true);

        // Establecer la conexión con la base de datos
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url = "jdbc:sqlserver://localhost:1433;databaseName=BichosDeBolsillo;integratedSecurity=true;TrustServerCertificate=true;";
            conn = DriverManager.getConnection(url);

            // Mostrar los datos existentes en la base de datos al iniciar el programa
            mostrarDatos();


            //Consulta
            String sql;
            Statement statement= conn.createStatement();
            System.out.println("************Recuperando las Especies de los Bichos*************");
            sql= "SELECT * FROM Especie";

            ResultSet resultSet= statement.executeQuery(sql);

            while (resultSet.next()) {
                int idEspecie = resultSet.getInt("ID_Especie");
                String nombreEspecie = resultSet.getString("Nombre_Especie");
                System.out.println(idEspecie + " " + nombreEspecie);
            }

            //Intentar una insertar una fila, y que el trigger no me permita 
            System.out.println("************Insertando un nuevo movimiento aprendido a bichos*************");
            sql = "INSERT INTO Movimiento_Aprendido (ID_Bicho, ID_Movimiento) VALUES (1, 4)";
            statement.executeUpdate(sql);

           
            // Llamar al procedimiento almacenado
            System.out.println("************Evolucionando el bicho 1 a la especie 2*************");
            int idBicho = 1; // El ID del bicho que quieres evolucionar
            int idEspecieDestino = 2; // El ID de la especie destino

            // Preparar el llamado al procedimiento almacenado
            CallableStatement callableStatement = conn.prepareCall("{call EvolucionarBicho(?, ?)}");
            callableStatement.setInt(1, idBicho);
            callableStatement.setInt(2, idEspecieDestino);

            // Ejecutar el procedimiento almacenado
            callableStatement.execute();
            System.out.println("El bicho " + idBicho + " ha sido evolucionado a la especie " + idEspecieDestino + ".");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Método para mostrar los datos existentes en la base de datos en la tabla visual
    private void mostrarDatos() {
        try {
            String sql = "SELECT * FROM Usuario";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            
            // Limpia las filas existentes en el modelo
            tm.setRowCount(0);
            
            while (rs.next()) {
                int ID_Usuario = rs.getInt("ID_Usuario");
                String Nombre = rs.getString("Nombre");
                String Sexo = rs.getString("Sexo");
                String Correo = rs.getString("Correo");
                String Pais = rs.getString("Pais");
                // Agrega una fila al modelo
                tm.addRow(new Object[]{ID_Usuario, Nombre, Sexo, Correo, Pais});
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    

    class FormPanel extends JPanel {
        public FormPanel() {
            setBorder(new EmptyBorder(8, 8, 8, 8));
            setLayout(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.fill = GridBagConstraints.BOTH;
            gbc.weightx = 1;

            NamePanel namePane = new NamePanel();
            namePane.setBorder(new CompoundBorder(new TitledBorder("Identificación"), new EmptyBorder(4, 4, 4, 4)));
            add(namePane, gbc);

            gbc.gridy++;
            TextPanel textPane = new TextPanel();
            textPane.setBorder(new CompoundBorder(new TitledBorder("Datos"), new EmptyBorder(4, 4, 4, 4)));
            add(textPane, gbc);
        }
    }
    class NamePanel extends JPanel {
        public NamePanel() {
            setLayout(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.anchor = GridBagConstraints.EAST;
    
            add(new JLabel("ID_Usuario: "), gbc);
            gbc.gridx += 2;
            add(new JLabel("Nombre: "), gbc);
            gbc.gridx += 2;
            add(new JLabel("Correo: "), gbc);
    
            gbc.gridy++;
            gbc.gridx = 0;
            add(new JLabel("Pais: "), gbc);
            gbc.gridx += 2;
    
            gbc.gridx = 1;
            gbc.gridy = 0;
            gbc.fill = GridBagConstraints.HORIZONTAL;
            gbc.anchor = GridBagConstraints.WEST;
            gbc.weightx = 0.5;
            add(ID_Usuario, gbc);
            gbc.gridx += 2;
            add(Nombre, gbc);
            gbc.gridx += 2;
            add(Correo, gbc);
    
            gbc.gridy++;
            gbc.gridx = 1;
            add(Pais, gbc);
            gbc.gridx += 2;
    
            gbc.gridx = 0;
            gbc.gridy++;
            gbc.anchor = GridBagConstraints.EAST;
            add(new JLabel("Sexo: "), gbc);
    
            gbc.gridx++;
            gbc.anchor = GridBagConstraints.WEST;
            gbc.fill = GridBagConstraints.HORIZONTAL;
            gbc.gridwidth = GridBagConstraints.REMAINDER;
            
            Sexo.addItem("M");
            Sexo.addItem("F");
            add(Sexo, gbc);
        }
    }
    

    class TextPanel extends JPanel implements ActionListener {
        public TextPanel() {
            JPanel detailsPane = new JPanel(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.fill = GridBagConstraints.BOTH;
            gbc.weighty = 1;
            gbc.gridwidth = GridBagConstraints.REMAINDER;
    
            String[] columnas = new String[]{"ID_Usuario", "Nombre", "Sexo", "Correo", "Pais"};
            tm = new DefaultTableModel();
            tm.setColumnIdentifiers(columnas); // Configura los nombres de las columnas
            tabla = new JTable(tm); // Asocia el modelo a la tabla
            spTexto = new JScrollPane(tabla);
            spTexto.setPreferredSize(new Dimension(spTexto.getPreferredSize().width, 120)); // Ajusta el tamaño de la tabla
            detailsPane.add(spTexto, gbc);
    
            JPanel buttonsPane = new JPanel(new FlowLayout());
            agregar.addActionListener(this);
            limpiar.addActionListener(this);
            borrar.addActionListener(this);
            actualizar.addActionListener(this);
            salir.addActionListener(this);
            
            buttonsPane.add(agregar);
            buttonsPane.add(limpiar);
            buttonsPane.add(borrar);
            buttonsPane.add(actualizar);
            buttonsPane.add(salir);
    
            setLayout(new BorderLayout());
            add(buttonsPane, BorderLayout.PAGE_START);
            add(detailsPane, BorderLayout.CENTER);
        }
    
        public void actionPerformed(ActionEvent e) {
            String evento = e.getActionCommand();
    
            if (evento.equals("Agregar")) {
                agregarRegistro();
            } else if (evento.equals("Limpiar")) {
                limpiarCampos();
            } else if (evento.equals("Borrar")) {
                borrarRegistro();
            } else if (evento.equals("Actualizar")) {
                actualizarRegistro();
            } else if (evento.equals("Salir")) {
                salirPrograma();
            }
        }
    
        // Métodos para agregar, limpiar, borrar, actualizar y salir
        // ... (Códigos para agregarRegistro, limpiarCampos, borrarRegistro, actualizarRegistro y salirPrograma)
    }
    
    private void agregarRegistro() {
        if (contador <= 30) {
            try {
                String sqlCheck = "SELECT COUNT(*) FROM Usuario WHERE ID_Usuario = ?";
                PreparedStatement pstmtCheck = conn.prepareStatement(sqlCheck);
                pstmtCheck.setInt(1, Integer.parseInt(ID_Usuario.getText()));
                ResultSet rsCheck = pstmtCheck.executeQuery();
                rsCheck.next();
                int count = rsCheck.getInt(1);
                if (count > 0) {
                    JOptionPane.showMessageDialog(null, "El ID ya existe en la base de datos.");
                    return;
                } else {
                    String sqlInsert = "INSERT INTO Usuario (ID_Usuario, Nombre, Sexo, Correo, Pais) VALUES (?, ?, ?, ?, ?)";
                    PreparedStatement pstmtInsert = conn.prepareStatement(sqlInsert);
                    pstmtInsert.setInt(1, Integer.parseInt(ID_Usuario.getText()));
                    pstmtInsert.setString(2, Nombre.getText());
                    pstmtInsert.setString(3, (String) Sexo.getSelectedItem());
                    pstmtInsert.setString(4, Correo.getText());
                    pstmtInsert.setString(5, Pais.getText());
                    pstmtInsert.executeUpdate();
                    mostrarDatos(); // Actualiza la tabla visual con los nuevos datos
                    contador++;
                    limpiarCampos();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        } else {
            JOptionPane.showMessageDialog(null, "No se pueden agregar más de 30 registros.");
        }
    }
    
        
        private void limpiarCampos() {
            ID_Usuario.setText("");
            Nombre.setText("");
            Sexo.setSelectedIndex(0);
            Correo.setText("");
            Pais.setText("");
        }

        private void borrarRegistro() {
            int filaSeleccionada = tabla.getSelectedRow();
            if (filaSeleccionada >= 0) {
                int confirmacion = JOptionPane.showConfirmDialog(null, "¿Estás seguro de que quieres borrar este registro?", "Confirmación de borrado", JOptionPane.YES_NO_OPTION);
                if (confirmacion == JOptionPane.YES_OPTION) {
                    try {
                        int idBorrar = (int) tabla.getValueAt(filaSeleccionada, 0);
                        String sqlDelete = "DELETE FROM Usuario WHERE ID_Usuario = ?";
                        PreparedStatement pstmtDelete = conn.prepareStatement(sqlDelete);
                        pstmtDelete.setInt(1, idBorrar);
                        pstmtDelete.executeUpdate();
                        mostrarDatos(); // Actualiza la tabla visual después del borrado
                        contador--;
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "Selecciona un registro para borrar.");
            }
        }
        
        private void actualizarRegistro() {
            int filaSeleccionada = tabla.getSelectedRow();
            if (filaSeleccionada >= 0) {
                int confirmacion = JOptionPane.showConfirmDialog(null, "¿Estás seguro de que quieres actualizar este registro?", "Confirmación de actualización", JOptionPane.YES_NO_OPTION);
                if (confirmacion == JOptionPane.YES_OPTION) {
                    try {
                        int idActualizar = (int) tabla.getValueAt(filaSeleccionada, 0);
                        String sqlUpdate = "UPDATE Usuario SET Nombre = ?, Sexo = ?, Correo = ?, Pais = ? WHERE ID_Usuario = ?";
                        PreparedStatement pstmtUpdate = conn.prepareStatement(sqlUpdate);
                        pstmtUpdate.setString(1, Nombre.getText());
                        pstmtUpdate.setString(2, (String) Sexo.getSelectedItem());
                        pstmtUpdate.setString(3, Correo.getText());
                        pstmtUpdate.setString(4, Pais.getText());
                        pstmtUpdate.setInt(5, idActualizar);
                        pstmtUpdate.executeUpdate();
                        mostrarDatos(); // Actualiza la tabla visual después de la actualización
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "Selecciona un registro para actualizar.");
            }
        }
        

        private void salirPrograma() {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            System.exit(0);
        }
    } 

